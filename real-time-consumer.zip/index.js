exports.handler = async (event) => {
  console.log('Received event:', JSON.stringify(event));

  // Process the event here

  return {
    statusCode: 200,
    body: 'Event processed successfully'
  };
};